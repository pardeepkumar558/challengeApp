$(document).ready(function () {

    $(document).on("scroll", function () {
        if ($(document).scrollTop() > 86) {
            $("#banner").addClass("shrink");
        }
        else {
            $("#banner").removeClass("shrink");
        }
    });
    
    $("#collapsibleNavbar").click(function () {
        $(this).toggleClass("show");
    });
});
